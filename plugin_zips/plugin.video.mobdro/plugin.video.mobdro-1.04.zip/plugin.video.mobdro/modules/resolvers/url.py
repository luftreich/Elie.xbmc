# -*- coding: utf-8 -*-

def parse_url(params):
    return params