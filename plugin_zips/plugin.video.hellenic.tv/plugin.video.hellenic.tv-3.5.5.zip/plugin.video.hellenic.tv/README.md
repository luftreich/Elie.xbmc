======================
Hellenic TV
======================

About
-----
Greek television


Attributions
---------------------
- Main icon by jokster | http://tvaddons.ag
- Main icon set by rayw1986 | http://tvaddons.ag


License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html